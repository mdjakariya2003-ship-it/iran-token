# Iran Token (IRAN), Solana Devnet

Devnet-only test token. No real monetary value. No Mainnet support.
Never commit .keys/ or .env. Never share your wallet file.

Steps: npm install, npm test, npm run wallet, npm run airdrop, npm run logo,
set your GitHub username in metadata/metadata.json and .env, push to GitHub,
npm run create, npm run verify -- <MINT>.
